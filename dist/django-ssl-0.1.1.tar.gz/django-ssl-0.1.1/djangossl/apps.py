from django.apps import AppConfig


class DjangosslConfig(AppConfig):
    name = 'djangossl'
